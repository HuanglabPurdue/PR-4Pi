//__device__ float factorial(int N);

//__device__ float RadialPolyomial(float rho,int m,int n);
__device__ void fkr(float factor, int n, int m,
					int kk, float k, float krmax,
					float rho, float phi,
					float Z,
					float * rnm,
					float  pCZ_real, float pCZ_imag,
					int ZernNum,
					float *IntRe, float *IntIm,
					float Lambda, float n_med, float n_imm,
					float depth, float focalDis, float kccd);

__device__ float PSF_point(float rho, float phi,
						float Z,
						float NA, float Lambda,
						int *pCZ_n, int *pCZ_m,
						float *pCZ_real, float *pCZ_imag,
						int *pZernNum,
						float * rnm,
						int Nzern,
						float n_med, float n_imm, float depth, float focalDis);

__device__ float OTFconvolve(const float * oldpsf, 
							 int boxsizeL, int tt, 
							 const float * OTFp, 
							 int x, int y, 
							 float I, float bg, float epsilon);

__global__ void kernel_PSF_image(int Boxsize, float PixelSize,
								float *Xpos, float *Ypos, float *Z,
								float NA, float Lambda, 
								int *pCZ_n, int *pCZ_m,
								float *pCZ_real, float *pCZ_imag,
								int *pZernNum,
								int Nzern,
								float * rnm,
								float *pPSF,
								float n_med, float n_imm, float depth, float focalDis);

__global__ void kernel_convolve(int boxsize, int FOTFsize, 
								const float * OTFp, 
								const float * oldPSF, 
								float * newPSF, 
								float *I, float *bg, float pixelsize);
