//#include <windows.h>
//#pragma comment(lib, "kernel32.lib")
//Localization algorithm for Astigmatism method

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mex.h>
#include <cuda_runtime.h>
#include "definitions.h"

/* the following definition makes indexing into the psf array easier in CalNextParamBi */

#define index(m,n) (m*8)*psfsize+(n)*psfsize+i
#define Vadex(m,n) (m*5)*psfsize+(n)*psfsize+i
// If you write any auxiliary functions, place them here


// This function is mandatory.  It takes the place of 'main' in c.
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
    
    /*!
 *  \brief Entry point in the code for Matlab.  Equivalent to main().
 *  \param nlhs number of left hand mxArrays to return
 *  \param plhs array of pointers to the output mxArrays
 *  \param nrhs number of input mxArrays
 *  \param prhs array of pointers to the input mxArrays.
 */
	//declare all vars
		// input data and paramters 
	float *channel1=0;
	float *Coords1=0;
	float *xIn=0;
	float  pixelsize;
	int	 boxsize;
	int channelNum;
	float Magnify;
	float NA, lambda, n_med, n_imm, depth;

	float *pCZ1_real=0,*pCZ1_imag=0; // pointers to zernike coefficients to be read in from function call (plane 1)
	float *d_zern1r = 0, *d_zern1i = 0; // pointers to copy of zernike coefficients on GPU (plane 1)
	float *OTFparam1=0; // pointers to OTF parameters to be read in from function call (both planes)
	float *d_OTFp1 = 0; // pointers to copy of OTF parameters on GPU (both planes)
	float *Rnm = 0, *d_Rnm = 0;  // pointers to precalculated Rnm table and copy on the GPU (same for both planes)
	int *pCZ1_n=0, *pCZ1_m=0;
	int *d_zern1n=0, *d_zern1m=0;
	int *d_zern1Num=0;
	int *pCZ1_Num=0;

	const mwSize *datasize1=0,*datasize2=0,*Zern_size_r1=0, *Zern_size_i1=0, *OTF_size1=0;
	const mwSize *Zern_size_n1=0, *Zern_size_m1=0, *Zern_size_Num1=0;

	mwSize outsize[1];
	mwSize outsize1[1];
	mwSize outsize2[1];
	mwSize outsize3[1];
	int iterateN1;
	float *result=0;
	float *convergence=0;
	float *bipsf=0;
	float *crlb=0;
	float *error=0;
	int Nzern1;
		// Local variables

	int Start,i,j,k;	
	float *x0=0;
	float *x0_next=0;	
	float *x0_Var=0;
	int psfsize;
	int x0Size=5;
	int OTFpsize=4;
	int resultSize=6;
	int errsize=2;
	float sse=0;
	float LLR=0;
	
	float RealX1,RealY1;
	int NzernS1;// number of Zernike coefficients

	size_t Ndimsreal,Ndimsimag,NdimData1;
	//check for required inputs, correct types, and dimensions
	//1D vectors still return 2D
	datasize1=mxGetDimensions(prhs[0]);
	datasize2=mxGetDimensions(prhs[17]);
	// get sizes of the zernike and OTF parameters
	Zern_size_r1=mxGetDimensions(prhs[2]);
	Zern_size_i1=mxGetDimensions(prhs[3]);

	Zern_size_n1=mxGetDimensions(prhs[5]);
	Zern_size_m1=mxGetDimensions(prhs[6]);
	Zern_size_Num1=mxGetDimensions(prhs[7]);

	OTF_size1 = mxGetDimensions(prhs[4]);
	NdimData1=mxGetNumberOfDimensions(prhs[0]);
	Ndimsreal=mxGetNumberOfDimensions(prhs[2]);
	Ndimsimag=mxGetNumberOfDimensions(prhs[3]);
	//retrieve all inputs	
	channel1=(float *) mxGetData(prhs[0]);
	Coords1=(float *) mxGetData(prhs[1]);
	pCZ1_real=(float *) mxGetData(prhs[2]);
	pCZ1_imag=(float *) mxGetData(prhs[3]);
	OTFparam1=(float *) mxGetData(prhs[4]);
	pCZ1_n=(int *) mxGetData(prhs[5]);
	pCZ1_m=(int *) mxGetData(prhs[6]);
	pCZ1_Num=(int *) mxGetData(prhs[7]);

	pixelsize=(float) mxGetScalar(prhs[8]);
	NA=(float) mxGetScalar(prhs[9]);
	lambda=(float) mxGetScalar(prhs[10]);
	iterateN1=(int) mxGetScalar(prhs[11]);
	boxsize=(int) mxGetScalar(prhs[12]);
	channelNum=(int) mxGetScalar(prhs[13]);
	n_med=(float) mxGetScalar(prhs[14]);
	n_imm = (float)mxGetScalar(prhs[15]);
	depth = (float)mxGetScalar(prhs[16]);
	Nzern1=(int)mxGetScalar(prhs[17]);
	xIn=(float *)mxGetData(prhs[18]);

	//allocate memory for variables other than input
	
	x0_next=(float *)mxCalloc(x0Size*channelNum,sizeof(float));
	x0_Var=(float*)mxCalloc(x0Size*channelNum,sizeof(float));
	x0=(float*)mxCalloc(x0Size*channelNum,sizeof(float));

	//validate input values(this section better not be blank!)
	//check dimensions
	if (NdimData1 != 2) 
        mexErrMsgTxt("Array of channel1 must be a N x 1 vector.");
    if (Ndimsreal != 2) 
        mexErrMsgTxt("Array of Real Zernike coefficients must be a N x 1 vector.");
    if (Ndimsimag != 2) 
        mexErrMsgTxt("Array of Imaginary Zernike coefficients must be a N x 1 vector.");
    //check sizes
	if (datasize1[1] != 1) 
        mexErrMsgTxt("Array of channel1 must be a N x 1 vector.");
	if (datasize2[1] != 1)
		mexErrMsgTxt("Array of x0 must be a N x 1 vector.");
	if (boxsize*boxsize!=datasize1[0]/channelNum)
		mexErrMsgTxt("boxsize must be square root of datasize.");
    if (Zern_size_r1[1] != 1) 
        mexErrMsgTxt("Array of Real Zernike coefficients for plane 1 must be a N x 1 vector.");
    if (Zern_size_i1[1] != 1) 
        mexErrMsgTxt("Array of Imaginary Zernike coefficients for plane 1 must be a N x 1 vector.");
	if (Zern_size_n1[1] != 1) 
        mexErrMsgTxt("Array of (n) Zernike coefficients for plane 1 must be a N x 1 vector.");
    if (Zern_size_m1[1] != 1) 
        mexErrMsgTxt("Array of (m) Zernike coefficients for plane 1 must be a N x 1 vector.");
	if (Zern_size_Num1[1] != 1) 
        mexErrMsgTxt("Array of (Number) Zernike coefficients for plane 1 must be a N x 1 vector.");
    //check that input data are float
    if (!mxIsSingle(prhs[0]))
        mexErrMsgTxt("data must be type single");
	if (!mxIsSingle(prhs[1]))
        mexErrMsgTxt("Coords must be type single");
	if (!mxIsSingle(prhs[2]))
        mexErrMsgTxt("Real Zernike coefficients1 must be type single");
    if (!mxIsSingle(prhs[3]))
        mexErrMsgTxt("Imaginary Zernike coefficients1 must be type single");
	if (!mxIsSingle(prhs[4]))
        mexErrMsgTxt("OTFparam1 must be type single");
	if (!mxIsInt32(prhs[5]))
        mexErrMsgTxt("(n) Zernike coefficients1 must be type int32");
    if (!mxIsInt32(prhs[6]))
        mexErrMsgTxt("(m) Zernike coefficients1 must be type int32");
    if (!mxIsInt32(prhs[7]))
        mexErrMsgTxt("(Number) Zernike coefficients1 must be type int32");
	if (!mxIsSingle(prhs[18]))
		mexErrMsgTxt("x0 must be type single");
	// compare sizes of Zernike and OTF parameters between planes
	if (Zern_size_r1[0] != Zern_size_i1[0])
		mexErrMsgTxt("Real and Imaginary Zernike coefficient arrays for plane 1 must be the same size");

	NzernS1=Zern_size_r1[0];
	int nmax = (int)sqrtf((float)Nzern1);
	int Rnmsize = (nmax*nmax+nmax)/2*SPD;
	Rnm = (float *)mxMalloc(Rnmsize*sizeof(float));
	if (!Rnm)
		mexErrMsgTxt("insufficient memory to store all radial polynomial coefficients");
	MakeRnmLookup(nmax,NA,lambda, Rnm);

	// allocate Zernike, OTF, and Rnm arrays on GPU
	cudasafe(cudaMalloc((void**) &d_Rnm, Rnmsize*sizeof(float)), "cudaMalloc d_rnm");
	cudasafe(cudaMemcpy(d_Rnm, Rnm, Rnmsize*sizeof(float), cudaMemcpyHostToDevice), "cudaMemcpy Rnm to device");
	mxFree(Rnm); // we no longer need the Rnm array on the CPU
	Rnm=0;

	cudasafe(cudaMalloc((void**) &d_zern1r, NzernS1*sizeof(float)), "cudaMalloc d_zern1r");
	cudasafe(cudaMemcpy(d_zern1r, pCZ1_real, NzernS1*sizeof(float), cudaMemcpyHostToDevice), "cudaMemcpy pCZ1_real to device"); 

	cudasafe(cudaMalloc((void**) &d_zern1i, NzernS1*sizeof(float)), "cudaMalloc d_zern1i");
	cudasafe(cudaMemcpy(d_zern1i, pCZ1_imag, NzernS1*sizeof(float), cudaMemcpyHostToDevice), "cudaMemcpy pCZ1_imag to device");

	cudasafe(cudaMalloc((void**) &d_OTFp1, OTF_size1[0]*sizeof(float)), "cudaMalloc d_OTFp1");
	cudasafe(cudaMemcpy(d_OTFp1, OTFparam1, OTF_size1[0]*sizeof(float), cudaMemcpyHostToDevice), "cudaMemcpy OTFparam1 to device");

    cudasafe(cudaMalloc((void**) &d_zern1n, NzernS1*sizeof(int)), "cudaMalloc d_zern1n");
	cudasafe(cudaMemcpy(d_zern1n, pCZ1_n, NzernS1*sizeof(int), cudaMemcpyHostToDevice), "cudaMemcpy pCZ1_n to device"); 

	cudasafe(cudaMalloc((void**) &d_zern1m, NzernS1*sizeof(int)), "cudaMalloc d_zern1m");
	cudasafe(cudaMemcpy(d_zern1m, pCZ1_m, NzernS1*sizeof(int), cudaMemcpyHostToDevice), "cudaMemcpy pCZ1_m to device");

	cudasafe(cudaMalloc((void**) &d_zern1Num, NzernS1*sizeof(int)), "cudaMalloc d_zern1Num");
	cudasafe(cudaMemcpy(d_zern1Num, pCZ1_Num, NzernS1*sizeof(int), cudaMemcpyHostToDevice), "cudaMemcpy pCZ1_Num to device");

	// create output
	
	outsize[0] = resultSize*channelNum;
	outsize1[0] = x0Size*channelNum;
	outsize2[0] = errsize*channelNum;
	outsize3[0] = boxsize*boxsize*channelNum;
	plhs[0]=mxCreateNumericArray(1,outsize,mxSINGLE_CLASS,mxREAL);
	plhs[1]=mxCreateNumericArray(1,outsize1,mxSINGLE_CLASS,mxREAL);
	plhs[2]=mxCreateNumericArray(1,outsize1,mxSINGLE_CLASS,mxREAL);
	plhs[3]=mxCreateNumericArray(1,outsize2,mxSINGLE_CLASS,mxREAL);
	plhs[4]=mxCreateNumericArray(1,outsize3,mxSINGLE_CLASS,mxREAL);
	result=(float *)mxGetData(plhs[0]);
	convergence=(float *)mxGetData(plhs[1]);
	crlb=(float *)mxGetData(plhs[2]);
	error=(float *)mxGetData(plhs[3]);
	bipsf=(float *)mxGetData(plhs[4]);
	//do stuff

	Start=(boxsize % 2 ==0 ? boxsize/2: (boxsize-1)/2);
	psfsize=boxsize*boxsize;
	// the following command will fill x0 with the initial guess for the parameters
	for(i=0;i<x0Size*channelNum;i++)
		x0[i]=xIn[i];
	//  iteration
	for(i=0;i<iterateN1;i++)
	{
		CalNextParamAst(x0_next,x0, 
					   channelNum,
					   channel1, 
					   d_OTFp1, 
					   d_zern1n,d_zern1m,
					   d_zern1r,
					   d_zern1i,
					   d_zern1Num,
					   NzernS1,
					   Start, boxsize, pixelsize, NA, 
					   lambda, n_med, n_imm,depth,
					   d_Rnm);

		if (i==iterateN1-1)
		{
			for(k=0;k<x0Size*channelNum;k++) {convergence[k]=abs(x0_next[k]-x0[k]);}
		}
		
		for(j=0;j<x0Size*channelNum;j++) {x0[j]=x0_next[j];}

	}

	//write x0 in fitting result
	for(k=0;k<channelNum;k++)
	{
		for(i=2;i<x0Size;i++) result[k*resultSize+i]=x0[k*x0Size+i];
		
	}

	// PSF Bipsf1, use x0
	float *xT1=0;
	float *yT1=0;
	float *zT1=0;
	float *IT1=0;
	float *bgT1=0;
	
	float *toppsf=0;

	xT1 = (float*)malloc(channelNum*sizeof(float));
	yT1 = (float*)malloc(channelNum*sizeof(float));
	zT1 = (float*)malloc(channelNum*sizeof(float));
	IT1 = (float*)malloc(channelNum*sizeof(float));
	bgT1 = (float*)malloc(channelNum*sizeof(float));
	toppsf = (float*)mxMalloc(psfsize*channelNum*sizeof(float));
	
	//mexPrintf("%.5f",cos_R);
	for(k=0;k<channelNum;k++)
	{
		xT1[k]=x0[k*x0Size+0];
		yT1[k]=x0[k*x0Size+1];
		IT1[k]=x0[k*x0Size+2];	
		bgT1[k]=x0[k*x0Size+3];	
		zT1[k]=x0[k*x0Size+4];

		RealX1=Coords1[k*3+0]+x0[k*x0Size+0];	
		RealY1=Coords1[k*3+1]+x0[k*x0Size+1];

		result[k*resultSize+0]=RealX1;
		result[k*resultSize+1]=RealY1;
		result[k*resultSize+5]=Coords1[k*3+2];
	}

	Modified_PSF(toppsf,xT1, yT1, zT1, 
				 d_zern1n,d_zern1m,
				 d_zern1r, d_zern1i, 
				 d_zern1Num,
				 NzernS1, 
				 channelNum, lambda, NA, pixelsize, boxsize, 
				 d_OTFp1, 
				 IT1, bgT1,
				 d_Rnm,
				 n_med, n_imm, depth, 0);

	for (i = 0; i<boxsize*boxsize*channelNum; i++) bipsf[i] = toppsf[i];
			

	/*for(i=0;i<4;i++)
		mexPrintf("%.5f ",OTFparam1[i]);*/

	for(k=0;k<channelNum;k++)
	{  
		sse=0;
		LLR=0;
		for(i=0;i<psfsize;i++)
		{
			sse+=pow(toppsf[k*psfsize+i]-channel1[k*psfsize+i],2);
			LLR+=2*(toppsf[k*psfsize+i]-channel1[k*psfsize+i]-channel1[k*psfsize+i]*log(toppsf[k*psfsize+i])+channel1[k*psfsize+i]*log(channel1[k*psfsize+i]));
			//mexPrintf("%.05f \n",toppsf[k*psfsize+i]);						
		}
		
		error[k*2+0]=sse;
		error[k*2+1]=LLR;

	}

	/*calculate CRLB*/
	CRLB_Ast3D(x0_Var,x0,
				   channelNum,
				   boxsize,pixelsize,Start,
				   NA,lambda,
				   n_med,n_imm,depth,
				   d_OTFp1,
				   d_zern1n,d_zern1m,
				   d_zern1r,
				   d_zern1i, 
				   d_zern1Num,
				   NzernS1,
				   d_Rnm);

	//copy crlb results back to matlab
	for(k=0;k<channelNum;k++)
	 {
		 crlb[k*x0Size+0]=x0_Var[k*x0Size+0];
		 crlb[k*x0Size+1]=x0_Var[k*x0Size+1];
		 crlb[k*x0Size+2]=x0_Var[k*x0Size+2];
		 crlb[k*x0Size+3]=x0_Var[k*x0Size+3];
		 crlb[k*x0Size+4]=x0_Var[k*x0Size+4];
	 }
	
	mxFree(toppsf);
	free(xT1);
	free(yT1);
	free(zT1);
	free(IT1);
	free(bgT1);

	toppsf = 0;
	
	//clean up anything not using an mxMalloc
	mxFree(x0_next);
	mxFree(x0_Var);
	mxFree(x0);
	x0_next = x0_Var = x0 = 0;

	// We're done with the GPU now, so free the constant arrays
	cudasafe(cudaFree(d_Rnm), "free d_Rnm");
	cudasafe(cudaFree(d_zern1r), "free d_zern1r");
	cudasafe(cudaFree(d_zern1i), "free d_zern1i");
	cudasafe(cudaFree(d_OTFp1), "free d_OTFp1");
	cudasafe(cudaFree(d_zern1n), "free d_zern1r");
	cudasafe(cudaFree(d_zern1m), "free d_zern1i");
	cudasafe(cudaFree(d_zern1Num), "free d_zern1i");

	d_Rnm = 0;
	d_zern1r = d_zern1i = d_OTFp1 = 0;
	d_zern1n = d_zern1m = 0;
	d_zern1Num = 0;

	cudaDeviceReset();

	return;
}

void CalNextParamAst(float *x0_next,float *x0, 
					int channelNum, 
					float *channel1, 
					float *d_OTFparam1,
					int *d_pCZ1_n,int *d_pCZ1_m,
					float *d_pCZ1_real, 
					float *d_pCZ1_imag,
					int *d_pZern1Num,
					int NzernS1,
					int Start, int boxsize,float pixelsize,float NA,
					float lambda,float n_med, float n_imm, float depth,
					float *d_Rnm)
 {
	 int i,j,k,t;
	 float xlim=0.2f, zlim=0.03f;
	 float Ilim=400, bglim=2;

	 float cf1,cf2;
	 float delta1=0.01f, delta2=0.01f, step;
	 const size_t size = boxsize*boxsize*sizeof(float);

	 int OTFpsize = 4;
	 int x0Size=5;
	 int psfNum=8;
	 int psfcount = psfNum*channelNum;; /* the number of psfs we need to calculate FOR EACH PLANE for Newton-Raphson */
	 int psfsize = boxsize*boxsize;
	 /* create 5 arrays--one for each parameter */
	 float *xtop=0;
	 float *ytop=0;
	 float *ztop=0;
	 float *Itop=0;
	 float *bgtop=0;

	 float *bipsftop=0; /* here is where the top multi-level psf will go */
	 float *df=0, *ddf=0;
	 float *funMaxa=0, *DfunMaxa=0;
	 float *ParamLimit=0;

	 xtop = (float*)mxMalloc(psfcount*sizeof(float));
	 ytop = (float*)mxMalloc(psfcount*sizeof(float));
	 ztop = (float*)mxMalloc(psfcount*sizeof(float));
	 Itop = (float*)mxMalloc(psfcount*sizeof(float));
	 bgtop = (float*)mxMalloc(psfcount*sizeof(float));
	 bipsftop = (float*)mxMalloc(psfsize*psfcount*sizeof(float));
	 df=(float*)mxMalloc(x0Size*sizeof(float));
	 ddf=(float*)mxMalloc(x0Size*sizeof(float));
	 funMaxa=(float*)mxMalloc(x0Size*sizeof(float));
	 DfunMaxa=(float*)mxMalloc(x0Size*sizeof(float));
	 ParamLimit=(float*)mxMalloc(x0Size*sizeof(float));

	 PopulArray(xtop,ytop,ztop,Itop,bgtop,
				x0Size,psfNum,delta1,delta2,
				channelNum,x0);

	 /* get the PSF stack for the top plane */
	 Modified_PSF(bipsftop, xtop, ytop, ztop, 
				  d_pCZ1_n,d_pCZ1_m,
				  d_pCZ1_real, d_pCZ1_imag,	
				  d_pZern1Num,
				  NzernS1, 
				  psfcount,lambda, NA, pixelsize, boxsize, 
				  d_OTFparam1, 
				  Itop,bgtop,
				  d_Rnm,
				  n_med, n_imm, depth, 0);
	 

	 //1st derivative
	 
	 ParamLimit[0]=xlim;
	 ParamLimit[1]=xlim;
	 ParamLimit[2]=Ilim;
	 ParamLimit[3]=bglim;
	 ParamLimit[4]=zlim;
	 /* Calculate the new x */
	 for(j=0;j<channelNum;j++)
	 {
		 for(k=0;k<x0Size;k++)
		 {
			 funMaxa[k]=0;
			 DfunMaxa[k]=0;
		 }
		 
		 for (i=0;i<psfsize;i++)
		 {
			 //x
			 df[0]=(bipsftop[index(j,2)]-bipsftop[index(j,0)])/delta1;
			 ddf[0]=(bipsftop[index(j,3)]-2*bipsftop[index(j,2)]+bipsftop[index(j,0)])/(delta1*delta1);
			 //y
			 df[1]=(bipsftop[index(j,4)]-bipsftop[index(j,0)])/delta1;
			 ddf[1]=(bipsftop[index(j,5)]-2*bipsftop[index(j,4)]+bipsftop[index(j,0)])/(delta1*delta1);
			 //I
			 df[2]=bipsftop[index(j,1)];
			 ddf[2]=0;
			 //bg
			 df[3]=1;
			 ddf[3]=0;
			 //z
			 df[4]=(bipsftop[index(j,6)]-bipsftop[index(j,0)])/delta2;
			 ddf[4]=(bipsftop[index(j,7)]-2*bipsftop[index(j,6)]+bipsftop[index(j,0)])/(delta2*delta2);

			 cf1=channel1[j*psfsize+i]/bipsftop[index(j,0)]-1;
			 cf2=channel1[j*psfsize+i]/(bipsftop[index(j,0)]*bipsftop[index(j,0)]);

			 for (k=0;k<x0Size;k++)
			 {
				 funMaxa[k] += cf1*df[k];
				 DfunMaxa[k] += cf1*ddf[k]-cf2*df[k]*df[k];
			 }
			 //mexPrintf("%.5f \n",bipsftop[index(j,2)]);
		 }

		 for (k=0;k<x0Size;k++)
		 {
			 step = funMaxa[k]/DfunMaxa[k];		 
			 x0_next[j*x0Size+k] = x0[j*x0Size+k]-min(max(step, -ParamLimit[k]),ParamLimit[k]);
		 }
		 
		 x0_next[j*x0Size+3]=(x0_next[j*x0Size+3]<=0 ? 0.01f:x0_next[j*x0Size+3]);// bg is not less than 0
		 x0_next[j*x0Size+2]=(x0_next[j*x0Size+2]<=0 ? 100:x0_next[j*x0Size+2]); // intensity is not less than 0		
		 x0_next[j*x0Size+0]=min(max(x0_next[j*x0Size+0]-Start,-Start+1),Start-1)+Start;// xy shift is within fitting box
		 x0_next[j*x0Size+1]=min(max(x0_next[j*x0Size+1]-Start,-Start+1),Start-1)+Start;

	 }

	 /* clean up */
	 mxFree(xtop);
	 mxFree(ytop);
	 mxFree(ztop);
	 mxFree(Itop);
	 mxFree(bgtop);
	 mxFree(bipsftop);
	 mxFree(ParamLimit);
	 mxFree(df);
	 mxFree(ddf);
	 mxFree(funMaxa);
	 mxFree(DfunMaxa);
	 xtop = ytop = ztop = Itop = 0;
	 bgtop = bipsftop = 0;
	 df = ddf = funMaxa =DfunMaxa = ParamLimit = 0;
}


void CRLB_Ast3D(float *x0_Var,float *x0,
					int channelNum,
					int boxsize,float pixelsize,int Start,
					float NA,float lambda,
					float n_med, float n_imm, float depth,
					float *d_OTFparam1,
					int *d_pCZ1_n,int *d_pCZ1_m,
					float *d_pCZ1_real,
					float *d_pCZ1_imag, 
					int *d_pZern1Num,
					int NzernS1,
					float *d_Rnm)
{
	int i,j,k,s,t;

	float delta1=0.01f;
	float tmp1;

	float *FisherM=0;
	float *funFi1=0;
	float *LowerBi=0;
	const size_t size = boxsize*boxsize*sizeof(float);

	int x0Size=5;
	int psfNum=5;
	int psfcount = psfNum*channelNum; /* the number of psfs we need to calculate for Newton-Raphson */
	int psfsize = boxsize*boxsize;
	/* create 5 arrays--one for each parameter */
	 float *xtop=0;
	 float *ytop=0;
	 float *ztop=0;
	 float *Itop=0;
	 float *bgtop=0;
	 float *PIx0=0, *PIy0=0,*PIi=0,*PIi0=0,*PIz0=0;
	 float * bipsftop=0; /* here is where the top multi-level psf will go */

	 FisherM=(float*)malloc(x0Size*x0Size*sizeof(float));
	 funFi1=(float*)malloc(x0Size*size);
	 LowerBi=(float*)malloc(x0Size*x0Size*sizeof(float));
	 xtop = (float*)mxMalloc(psfcount*sizeof(float));
	 ytop = (float*)mxMalloc(psfcount*sizeof(float));
	 ztop = (float*)mxMalloc(psfcount*sizeof(float));
	 Itop = (float*)mxMalloc(psfcount*sizeof(float));
	 bgtop = (float*)mxMalloc(psfcount*sizeof(float));
	 bipsftop = (float*)mxMalloc(psfsize*psfcount*sizeof(float));

	 PopulArray(xtop,ytop,ztop,Itop,bgtop,
				x0Size,psfNum,delta1,delta1,
				channelNum,x0);

	/* get the PSF stack for the top plane */
	 Modified_PSF(bipsftop, xtop, ytop, ztop, 
				  d_pCZ1_n,d_pCZ1_m,
				  d_pCZ1_real, d_pCZ1_imag,	
				  d_pZern1Num,
				  NzernS1, 
				  psfcount,lambda, NA, pixelsize, boxsize, 
				  d_OTFparam1, 
				  Itop,bgtop,
				  d_Rnm,
				  n_med, n_imm, depth, 0);

	 
	/*for(i=0;i<psfsize;i++)
		mexPrintf("botpsf %0.5f \n",bipsfbot[i]);*/
	
	  /* We now have the multiple psf as a single large array. Use it to compute the next set of parameters */

	 /* Calculate Fisher Information matrix*/
	 for(s=0;s<channelNum;s++)
	 {
		 for(i=0;i<psfsize;i++)
		 {   //x 
			 funFi1[0*psfsize+i]=(bipsftop[Vadex(s,2)]-bipsftop[Vadex(s,0)])/delta1;
			 //y
			 funFi1[1*psfsize+i]=(bipsftop[Vadex(s,3)]-bipsftop[Vadex(s,0)])/delta1;
			 //I plane1
			 funFi1[2*psfsize+i]=bipsftop[Vadex(s,1)];
			 // bg1
			 funFi1[3*psfsize+i]=1;
			 //z
			 funFi1[4*psfsize+i]=(bipsftop[Vadex(s,4)]-bipsftop[Vadex(s,0)])/delta1;
			 
			 //mexPrintf("%.5f \n", bipsf[Vadex(s,3)]);
		 }


		 for(j=0;j<x0Size;j++)
		 {
			 for(k=0;k<x0Size;k++)
			 {	
				 tmp1=0;
				 for(i=0;i<psfsize;i++)
				 {	 bipsftop[Vadex(s,0)]=max(bipsftop[Vadex(s,0)],1e-4f);
					 tmp1+=funFi1[j*psfsize+i]*funFi1[k*psfsize+i]/bipsftop[Vadex(s,0)];
				 } 

				 FisherM[j*x0Size+k]=tmp1;
			 }
		 }

		 MatrixInv(LowerBi,FisherM,x0Size);
		 for(i=0;i<x0Size;i++) x0_Var[s*x0Size+i]=LowerBi[i*x0Size+i];
	 } 
	 
	 //mexPrintf("%.5f \n", x0_Var[0]);

	 free(LowerBi);
	 free(FisherM);
	 free(funFi1);

	 mxFree(xtop);
	 mxFree(ytop);
	 mxFree(ztop);
	 mxFree(Itop);
	 mxFree(bgtop);
	 mxFree(bipsftop);
	 xtop = ytop = ztop = Itop = 0;
	 bgtop = bipsftop = 0;

}

void PopulArray(float *xtop, float *ytop, float *ztop, float *Itop, float *bgtop,
				 int x0Size,int psfNum,float delta1,float delta2,
				 int channelNum,float *x0)
{
	int t,j;
	float *PIx0=0, *PIy0=0,*PIi=0,*PIi0=0,*PIz0=0;
	PIx0=(float*)mxMalloc(psfNum*sizeof(float));
	PIy0=(float*)mxMalloc(psfNum*sizeof(float));
	PIi0=(float*)mxMalloc(psfNum*sizeof(float));
	PIz0=(float*)mxMalloc(psfNum*sizeof(float));
	PIi=(float*)mxMalloc(psfNum*sizeof(float));

	for(t=0;t<psfNum;t++)
	 {
		 PIx0[t]=0;
		 PIy0[t]=0;
		 PIz0[t]=0;
		 PIi0[t]=0;
		 PIi[t]=1;

	 }

	switch (psfNum){
	case 8:
		PIx0[2]=delta1;
		PIx0[3]=2*delta1;
		PIy0[4]=delta1;
		PIy0[5]=2*delta1;
		PIz0[6]=delta2;
		PIz0[7]=2*delta2;
		PIi0[1]=1;
		PIi[1]=0;
		break;
	case 5:
		PIx0[2]=delta1;
		PIy0[3]=delta1;
		PIz0[4]=delta1;
		PIi0[1]=1;
		PIi[1]=0;
		break;
	}

	 for(j=0;j<channelNum;j++)
	 {
		 for(t=0;t<psfNum;t++)
		 {
			 xtop[j*psfNum+t] = x0[j*x0Size+0]+PIx0[t];
			 ytop[j*psfNum+t] = x0[j*x0Size+1]+PIy0[t];
			 Itop[j*psfNum+t] = x0[j*x0Size+2]*PIi[t]+PIi0[t];
			 bgtop[j*psfNum+t] = x0[j*x0Size+3]*PIi[t];
			 ztop[j*psfNum+t] = x0[j*x0Size+4]+PIz0[t];
		 }

	 }

	 mxFree(PIx0);
	 mxFree(PIy0);
	 mxFree(PIz0);
	 mxFree(PIi0);
	 mxFree(PIi);
	 PIx0 = PIy0 = PIz0 = PIi0 = PIi = 0;


}