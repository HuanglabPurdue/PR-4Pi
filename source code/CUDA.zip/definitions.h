/*!
 * \file definitions.h
 * \author <your name>
 * \date April 20, 2012
 * \brief  If you are defining any constants they better be in this file and only this file.
 */

#ifndef DEFINITIONS_H
#define DEFINITIONS_H
#ifndef max
//! not defined in the C standard used by visual studio
#define max(a,b) (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
//! not defined in the C standard used by visual studio
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif

#define PI 3.141592f
#define SPD 64

#endif

void cudasafe( cudaError_t err, char* str);

void cudaError();

void MakeRnmLookup(int nmax,float NA, float lambda, float * Rnm);


void CalNextParamAst(float *x0_next, float *x0,
					int channelNum,
					float *channel1,
					float *d_OTFparam1,
					int *d_pCZ1_n, int *d_pCZ1_m,
					float *d_pCZ1_real,
					float *d_pCZ1_imag,
					int *d_pZern1Num,
					int NzernS1,
					int Start, int boxsize, float pixelsize, float NA,
					float lambda, float n_med, float n_imm, float depth,
					float *d_Rnm);


void CRLB_Ast3D(float *x0_Var, float *x0,
				int channelNum,
				int boxsize, float pixelsize, int Start,
				float NA, float lambda,
				float n_med, float n_imm, float depth,
				float *d_OTFparam1,
				int *d_pCZ1_n, int *d_pCZ1_m,
				float *d_pCZ1_real,
				float *d_pCZ1_imag,
				int *d_pZern1Num,
				int NzernS1,
				float *d_Rnm);

void PopulArray(float *xtop, float *ytop, float *ztop, float *Itop, float *bgtop,
				int x0Size, int psfNum, float delta1, float delta2,
				int channelNum, float *x0);


void Modified_PSF(float *output, const float *x, const float *y, const float *z,
				int *d_zcn, int *d_zcm,
				float *d_zcr, float *d_zci,
				int *dZernNum,
				int NzernS,
				int numpsf, const float lambda, const float NA, const float pixelsize, const int boxsize,
				float *d_OTFparam,
				float *I, float *bg1,
				float *d_rnm,
				float n_med, float n_imm, float depth, float focalDis);

void MatrixInv(float *M_inv,float *A, int sz);
void LU_decom(float *LU, int *mutate, float *A, int sz);