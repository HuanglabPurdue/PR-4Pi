#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mex.h>
#include <cuda_runtime.h>
#include "definitions.h"

void cudasafe( cudaError_t err, char* str)
{
 if (err != cudaSuccess)
 {
  mexPrintf("%s failed with error code %i\n",str,err);
  exit(1);
 }
}

void cudaError() {
/*!
 *  \brief A simple function to dump Cuda errors and abort the run.
 *  \param instr unused string pointer
 */
    cudaError_t errornum;
    const char *str; 
    if (errornum=cudaGetLastError()) {
        str=cudaGetErrorString(errornum);
        mexPrintf("%s\n", str);
        mexPrintf("You should clear this function in MATLAB for proper operation.\n", str);
    }
}

void MakeRnmLookup(int nmax,float NA, float lambda, float * Rnm)
{
	const float fact[] = {1.0f, 1.0f, 2.0f, 6.0f, 24.0f, 120.0f, 720.0f, 5040.0f, 40320.0f, 
						362880.0f, 3628800.0f, 39916800.0f, 479001600.0f, 6227020800.0f, 87178291200.0f};
	int count=0;
	float krmax=NA/lambda;
	float dkr = krmax/SPD;
	float krRadPoly;
	float kr;
	int nn,mm,s,kk;
	


	
	for (nn=0; nn<nmax; nn++)
	{
		for (mm=nn; mm>-1; mm--)
		{
			for (kk=0;kk<SPD;kk++)
			{
				kr=dkr*kk;
				krRadPoly = kr/krmax;
				if (nn==0)
					Rnm[count++] = 1;
				else
				{
					Rnm[count] = 0;
					for (s=0; s<nn-mm+1; s++)
						Rnm[count] += powf(-1.0f, s)*fact[2*nn-mm-s]/(fact[s]*fact[nn-s]*fact[nn-mm-s]) * powf(krRadPoly, 2*(nn-mm-s));
					Rnm[count]*=powf(krRadPoly, (float)mm);
					count++;
				}
			}
		}

	}
}

void MatrixInv(float *M_inv,float *A, int sz)
{
	int i,j,k;
	float tmp1;
	float *LU=0;
	int *mutate=0;
	float *Y=0;
	float *Identity=0;


	LU=(float*)malloc(sz*sz*sizeof(float));
	mutate=(int*)malloc(sz*sizeof(int));
	Y=(float*)malloc(sz*sz*sizeof(float));
	Identity=(float*)malloc(sz*sz*sizeof(float));

	for(i=0;i<sz;i++)
	{
		for(j=0;j<sz;j++)
		{
			if(i==j)
				Identity[i*sz+j]=1;
			else
				Identity[i*sz+j]=0;
		}
	}

	
    LU_decom(LU,mutate,A,sz);
	

	for(j=0;j<sz;j++)
	{
		for(i=0;i<sz;i++)
		{
			tmp1=0;
			if(i==0)
			{
				Y[i*sz+j]=Identity[mutate[i]*sz+j];
			}
			else
			{
				for(k=0;k<=i-1;k++) tmp1+=LU[i*sz+k]*Y[k*sz+j];
				Y[i*sz+j]=Identity[mutate[i]*sz+j]-tmp1;
			}
		}

		for(i=sz-1;i>=0;i--)
		{
			
			tmp1=0;
			if(i==(sz-1))
			{
				M_inv[i*sz+j]=Y[i*sz+j]/LU[i*sz+i];
			}
			else
			{
				for(k=i+1;k<sz;k++) tmp1+=LU[i*sz+k]*M_inv[k*sz+j];
				M_inv[i*sz+j]=(Y[i*sz+j]-tmp1)/LU[i*sz+i];
				//mexPrintf("LU : %0.5f \n",LU[i*sz+i]);
			}
		}
	}

	

	free(LU);
	free(mutate);
	free(Y);
	free(Identity);
	LU = 0;
	mutate = 0;
	Y=0;
	Identity=0;

}


void LU_decom(float *LU, int *mutate, float *A, int sz)
{
	int i,j,k,s;
	int n,tt;
	float tmp1,p;
	
	float *row0=0;

	row0=(float*)malloc(sz*sizeof(float));


	for(s=0;s<sz;s++) mutate[s]=s;

	for(j=0;j<sz;j++)
	{
		for(i=0;i<=j;i++)
		{
			tmp1=0;
			if(i==0)
			{
				LU[i*sz+j]=A[i*sz+j];
			}
			else
			{
				for(k=0;k<=i-1;k++) tmp1+=LU[i*sz+k]*LU[k*sz+j];
					LU[i*sz+j]=A[i*sz+j]-tmp1;
					//mexPrintf("%0.5f \n",LU[i*sz+j]);
			}
			
			if(i==j)
			{
				p=abs(LU[i*sz+j]);
				n=j;
			}
		}

		for(i=j+1;i<sz;i++)
		{
			tmp1=0;
			if(j==0)
			{
				LU[i*sz+j]=A[i*sz+j];
			}
			else
			{
				for(k=0;k<=j-1;k++) tmp1+=LU[i*sz+k]*LU[k*sz+j];
				LU[i*sz+j]=A[i*sz+j]-tmp1;
			}

			if(abs(LU[i*sz+j])>p)
			{
				p=abs(LU[i*sz+j]);
				n=i;
			}

			//if(p==0)
			if(n!=j)
			{
				for(s=0;s<sz;s++) row0[s]=LU[j*sz+s];
				for(s=0;s<sz;s++) LU[j*sz+s]=LU[n*sz+s];
				for(s=0;s<sz;s++) LU[n*sz+s]=row0[s];

				for(s=0;s<sz;s++) row0[s]=A[j*sz+s];
				for(s=0;s<sz;s++) A[j*sz+s]=A[n*sz+s];
				for(s=0;s<sz;s++) A[n*sz+s]=row0[s];

				tt=mutate[j];
				mutate[j]=mutate[n];
				mutate[n]=tt;
				n=j;
			}

		}
		//tmp2=LU[j*sz+j];
		//if (tmp2==0) LU[j*sz+j]=1e-6;
		
		LU[j*sz+j]=max(abs(LU[j*sz+j]),1e-5f)*LU[j*sz+j]/abs(LU[j*sz+j]);
		for(i=j+1;i<sz;i++) {LU[i*sz+j]/=LU[j*sz+j];
		                      
		}


		
	}

	//for(j=0;j<sz;j++)
	//mexPrintf("%0.5f \n",LU[j*sz+j]);

	free(row0);
	row0=0;
}
